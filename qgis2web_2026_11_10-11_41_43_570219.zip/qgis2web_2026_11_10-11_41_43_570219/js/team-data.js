/* =========================================================
   DATA TIM PENGEMBANG
   nama  : nama lengkap
   nim   : NIM anggota
   peran : tugas dalam tim
   foto  : path file gambar di folder foto/ (kosongkan '' jika belum ada)
   ========================================================= */
var TEAM = [
  { nama: 'Muhammad Huda',          nim: '24051874078', peran: 'Ketua Tim', foto: 'fotohuda.jpg.jpeg' },
  { nama: 'Daffa Tito Restu Putra', nim: '24051874074', peran: 'Anggota Tim',     foto: 'fotodaffa.jpg.jpeg' },
  { nama: 'Cicilia Amanda Herman',  nim: '24051874076', peran: 'Anggota Tim',     foto: 'fotocici.jpg.jpeg' },
  { nama: 'Rahmad Hakim Saputra',   nim: '24051874066', peran: 'Anggota Tim',     foto: 'fotohakim.jpg.jpeg' },
  { nama: 'Rahma Alfiyanti',        nim: '24051874081', peran: 'Anggota Tim',     foto: 'fotorahma.jpg.jpeg' },
  { nama: 'Rivya Rahmalia Abdillah',nim: '24051874064', peran: 'Anggota Tim',     foto: 'fotoryva.jpg.jpeg' },
  { nama: 'Anisa Kurnia Sari',      nim: '24051874067', peran: 'Anggota Tim',     foto: 'fotonisa.jpg.jpeg' }
];