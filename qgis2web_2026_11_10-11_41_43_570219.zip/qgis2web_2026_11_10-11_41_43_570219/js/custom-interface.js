/* =========================================================
   CUSTOM INTERFACE LOGIC & MAP INTERACTION ENGINE
   PORTAL WEBGIS PWK - UNESA
   ========================================================= */

// 1. Fungsi Sidebar Open/Close (Toggle)
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('collapsed');
        setTimeout(function () {
            if (typeof map !== 'undefined') {
                map.invalidateSize(); // Reset ukuran peta Leaflet agar tidak blur
            }
        }, 300);
    }
}

// 2. Fungsi Accordion Kelompok Layer
function toggleAccordion(headerElement) {
    var accordion = headerElement.parentElement;
    accordion.classList.toggle('active');
}

// 3. Switcher View (Beranda vs Peta Interaktif)
function switchView(viewName) {
    var landingView = document.getElementById('landing-view');
    var mapView = document.getElementById('map-view');
    var navBeranda = document.getElementById('nav-beranda');
    var navPeta = document.getElementById('nav-peta');

    if (viewName === 'map') {
        if (landingView) landingView.classList.remove('active');
        if (mapView) mapView.classList.add('active');
        if (navBeranda) navBeranda.classList.remove('active');
        if (navPeta) navPeta.classList.add('active');
        setTimeout(function () {
            if (typeof map !== 'undefined') {
                map.invalidateSize();
            }
        }, 200);
    } else {
        if (mapView) mapView.classList.remove('active');
        if (landingView) landingView.classList.add('active');
        if (navPeta) navPeta.classList.remove('active');
        if (navBeranda) navBeranda.classList.add('active');
    }
}

// 4. Reset Map View ke Bounds Awal
function resetMapView() {
    if (typeof bounds_group !== 'undefined' && bounds_group.getLayers().length > 0) {
        map.fitBounds(bounds_group.getBounds());
    }
}

// 5. Trigger Tool Penggaris (Leaflet Measure)
function triggerMeasureTool() {
    var measureBtn = document.querySelector('.leaflet-control-measure-toggle');
    if (measureBtn) {
        measureBtn.click();
    } else {
        alert('Fitur pengukur jarak & luas siap digunakan pada peta.');
    }
}

// 6. Kontrol Opasitas/Transparansi Layer
function toggleOpacityControl(layerKey) {
    var box = document.getElementById('opacity-box-' + layerKey);
    if (box) {
        box.classList.toggle('active');
    }
}

// 7. Event Listener Utama setelah DOM Selesai Dimuat
document.addEventListener('DOMContentLoaded', function () {
    
    // Live Clock Update (Jam Digital)
    setInterval(function () {
        var clockEl = document.getElementById('live-clock');
        if (clockEl) {
            var now = new Date();
            clockEl.innerText = now.toLocaleTimeString('id-ID') + ' WIB';
        }
    }, 1000);

    // Coordinate Tracker pada Canvas Peta
    if (typeof map !== 'undefined') {
        map.on('mousemove', function (e) {
            var coordEl = document.getElementById('cursor-coordinates');
            if (coordEl) {
                coordEl.innerText = 'Lat: ' + e.latlng.lat.toFixed(5) + ' | Lng: ' + e.latlng.lng.toFixed(5);
            }
        });
    }

    // Toggle Checkbox Layer On/Off Dinamis
    var checkboxes = document.querySelectorAll('.layer-checkbox');
    checkboxes.forEach(function (cb) {
        cb.addEventListener('change', function () {
            var layerVarName = this.getAttribute('data-layer');
            if (window[layerVarName] && typeof map !== 'undefined') {
                if (this.checked) {
                    map.addLayer(window[layerVarName]);
                } else {
                    map.removeLayer(window[layerVarName]);
                }
            }
        });
    });

    // Opacity Range Slider Dinamis
    var opacitySliders = document.querySelectorAll('.opacity-slider');
    opacitySliders.forEach(function (slider) {
        slider.addEventListener('input', function () {
            var layerVarName = this.getAttribute('data-layer');
            var val = parseFloat(this.value);
            if (window[layerVarName] && typeof window[layerVarName].setStyle === 'function') {
                window[layerVarName].setStyle({ fillOpacity: val, opacity: val });
            }
        });
    });

    // Switcher Basemap (Google Satellite, Esri, OSM, Carto)
    var bmButtons = document.querySelectorAll('.bm-btn');
    bmButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            bmButtons.forEach(function (b) { b.classList.remove('active'); });
            this.classList.add('active');
            var selectedBm = this.getAttribute('data-basemap');

            if (typeof map !== 'undefined') {
                // Sembunyikan semua Basemap bawaan
                if (window.layer_GoogleSatellite_0) map.removeLayer(layer_GoogleSatellite_0);
                if (window.layer_ESRITransportation_1) map.removeLayer(layer_ESRITransportation_1);

                // Tampilkan basemap pilihan
                if (selectedBm === 'google_sat' && window.layer_GoogleSatellite_0) {
                    map.addLayer(layer_GoogleSatellite_0);
                } else if (selectedBm === 'esri_trans' && window.layer_ESRITransportation_1) {
                    map.addLayer(layer_ESRITransportation_1);
                }
            }
        });
    });

    // Hitung Dashboard Statistik Otomatis dari Fitur GeoJSON
    setTimeout(function () {
        if (window.json_Kesehatan_8 && document.getElementById('stat-health')) {
            document.getElementById('stat-health').innerText = window.json_Kesehatan_8.features.length;
        }
        if (window.json_Sekolah_7 && document.getElementById('stat-school')) {
            document.getElementById('stat-school').innerText = window.json_Sekolah_7.features.length;
        }
        if (window.json_Kemancetan_6 && document.getElementById('stat-jam')) {
            document.getElementById('stat-jam').innerText = window.json_Kemancetan_6.features.length;
        }
        if (window.json_Rute_Jalan_3 && document.getElementById('stat-paths')) {
            document.getElementById('stat-paths').innerText = window.json_Rute_Jalan_3.features.length;
        }
    }, 500);
});

// 8. Modal Navigasi Public & Informasi (Termasuk Data 7 Anggota Tim)
function showNavInfo(type) {
    var modal = document.getElementById('atrbpn-modal');
    var title = document.getElementById('modal-title');
    var body = document.getElementById('modal-body-content');

    if (!modal || !title || !body) return;

    if (type === 'katalog') {
        title.innerHTML = '<i class="fas fa-layer-group"></i> Katalog Layer Spasial';
        body.innerHTML = `
            <table class="katalog-table">
                <thead>
                    <tr>
                        <th>Nama Layer</th>
                        <th>Tipe Spasial</th>
                        <th>Deskripsi Data</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td>Batas Kecamatan</td><td><span class="badge-cat">Polygon</span></td><td>Wilayah administrasi kecamatan beserta atribut kependudukan</td></tr>
                    <tr><td>Jaringan Jalan Utama</td><td><span class="badge-cat">LineString</span></td><td>Jaringan jalan arteri, kolektor, lokal, dan tol</td></tr>
                    <tr><td>Rute Terpendek</td><td><span class="badge-cat">LineString</span></td><td>Analisis rute transportasi dengan jarak minimum</td></tr>
                    <tr><td>Rute Tercepat</td><td><span class="badge-cat">LineString</span></td><td>Analisis rute transportasi dengan waktu tempuh minimum</td></tr>
                    <tr><td>Fasilitas Kesehatan</td><td><span class="badge-cat">Point</span></td><td>Sebaran Rumah Sakit, Puskesmas, dan Klinik</td></tr>
                    <tr><td>Data Sekolah</td><td><span class="badge-cat">Point</span></td><td>Sebaran SD, SMP, SMA, dan Perguruan Tinggi</td></tr>
                    <tr><td>Titik Kemacetan</td><td><span class="badge-cat">Point</span></td><td>Lokasi titik simpul rawan kemacetan lalu lintas</td></tr>
                </tbody>
            </table>`;
    } else if (type === 'tentang') {
        title.innerHTML = '<i class="fas fa-users"></i> Tim Pengembang WebGIS PWK';
        body.innerHTML = `
            <p style="margin-bottom: 15px;">Portal Geospasial Interaktif ini dikembangkan secara kolaboratif oleh <strong>Tim Mahasiswa Perencanaan Wilayah dan Kota (PWK) Universitas Negeri Surabaya</strong>:</p>
            
            <div class="team-grid">
                <!-- Anggota 1 -->
                <div class="team-card">
                    <img src="images/foto1.jpg" class="team-img" alt="Foto Anggota 1" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Muhammad Huda</div>
                    <span class="team-role">24051874078 / Leader</span>
                </div>

                <!-- Anggota 2 -->
                <div class="team-card">
                    <img src="images/foto2.jpg" class="team-img" alt="Foto Anggota 2" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 2</div>
                    <span class="team-role">NIM / Peran</span>
                </div>

                <!-- Anggota 3 -->
                <div class="team-card">
                    <img src="images/foto3.jpg" class="team-img" alt="Foto Anggota 3" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 3</div>
                    <span class="team-role">NIM / Peran</span>
                </div>

                <!-- Anggota 4 -->
                <div class="team-card">
                    <img src="images/foto4.jpg" class="team-img" alt="Foto Anggota 4" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 4</div>
                    <span class="team-role">NIM / Peran</span>
                </div>

                <!-- Anggota 5 -->
                <div class="team-card">
                    <img src="images/foto5.jpg" class="team-img" alt="Foto Anggota 5" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 5</div>
                    <span class="team-role">NIM / Peran</span>
                </div>

                <!-- Anggota 6 -->
                <div class="team-card">
                    <img src="images/foto6.jpg" class="team-img" alt="Foto Anggota 6" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 6</div>
                    <span class="team-role">NIM / Peran</span>
                </div>

                <!-- Anggota 7 -->
                <div class="team-card">
                    <img src="images/foto7.jpg" class="team-img" alt="Foto Anggota 7" onerror="this.src='https://via.placeholder.com/70/0c2340/ffffff?text=User'">
                    <div class="team-name">Nama Anggota 7</div>
                    <span class="team-role">NIM / Peran</span>
                </div>
            </div>`;
    } else {
        title.innerHTML = '<i class="fas fa-circle-info"></i> Informasi Publik';
        body.innerHTML = `
            <p>Sistem Informasi Geospasial ini menyajikan data pemetaan wilayah terintegrasi untuk mendukung proses perencanaan, analisis wilayah, dan penyampaian informasi spasial publik secara transparan dan akurat.</p>`;
    }

    modal.classList.add('active');
}

// 9. Fungsi Tutup Modal Interaktif
function closeModal() {
    var modal = document.getElementById('atrbpn-modal');
    if (modal) modal.classList.remove('active');
}

function closeModalOnOuterClick(e) {
    if (e.target.id === 'atrbpn-modal') closeModal();
}

// 10. Zoom Smooth ke Layer Spesifik dari Sidebar
function zoomToLayerSmooth(layerName) {
    if (window[layerName] && typeof window[layerName].getBounds === 'function' && typeof map !== 'undefined') {
        map.fitBounds(window[layerName].getBounds(), { padding: [30, 30] });
    }
}